﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Microsoft.Phone.Notification;
using System.Diagnostics;

namespace WP7Recipe09_Push_Notification
{
    public partial class MainPage : PhoneApplicationPage
    {
        private const string channelName = "NotificationTest";
        
        HttpNotificationChannel notificationChannel;
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        private void ContentPanel_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            
        }

        void notificationChannel_ChannelUriUpdated(object sender, NotificationChannelUriEventArgs e)
        {
            Debug.WriteLine(e.ChannelUri);
        }

        void notificationChannel_ErrorOccurred(object sender, NotificationChannelErrorEventArgs e)
        {
            Debug.WriteLine(string.Format("Message:{0}\r\n code:{1}\r\n additionalData:{2}",e.Message,e.ErrorCode, e.ErrorAdditionalData));
        }

        void notificationChannel_ShellToastNotificationReceived(object sender, NotificationEventArgs e)
        {
            //throw new NotImplementedException();
        }

        void notificationChannel_HttpNotificationReceived(object sender, HttpNotificationEventArgs e)
        {
            //throw new NotImplementedException();
        }

        private void initNofiticationChannel()
        {
            try
            {
                notificationChannel = HttpNotificationChannel.Find(channelName);
                if (notificationChannel == null)
                {
                    notificationChannel = new HttpNotificationChannel(channelName);

                    notificationChannel.ErrorOccurred += new EventHandler<NotificationChannelErrorEventArgs>(notificationChannel_ErrorOccurred);
                    notificationChannel.ChannelUriUpdated += new EventHandler<NotificationChannelUriEventArgs>(notificationChannel_ChannelUriUpdated);
                    notificationChannel.Open();
                }
                else
                {
                    Debug.WriteLine(notificationChannel.ChannelUri.AbsoluteUri);
                }
                if (!notificationChannel.IsShellTileBound)
                    notificationChannel.BindToShellTile();

                if (!notificationChannel.IsShellToastBound)
                    notificationChannel.BindToShellToast();

                notificationChannel.HttpNotificationReceived += new EventHandler<HttpNotificationEventArgs>(notificationChannel_HttpNotificationReceived);
                notificationChannel.ShellToastNotificationReceived += new EventHandler<NotificationEventArgs>(notificationChannel_ShellToastNotificationReceived);

            }
            catch (InvalidOperationException ex)
            {
                //disable Push Notification in your application
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            initNofiticationChannel();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<HttpNotificationChannel> channels = new List<HttpNotificationChannel>();
                for (int i = 0; i < 50; i++)
                {
                    channels.Add(new HttpNotificationChannel(i.ToString()));
                }
                foreach (var item in channels)
                {
                    item.Open();
                }
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(ex.GetType().ToString());
                throw;
            }
        }
    }
}